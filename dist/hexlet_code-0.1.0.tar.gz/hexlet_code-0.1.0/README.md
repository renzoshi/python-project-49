### Hexlet tests and linter status:
[![Actions Status](https://github.com/renzoshi/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/renzoshi/python-project-49/actions)
<a href="https://codeclimate.com/github/renzoshi/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/550b267101c2a5a3f221/maintainability" /></a>